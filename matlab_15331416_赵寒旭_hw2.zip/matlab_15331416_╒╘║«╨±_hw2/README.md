# Image_hw2
# 15331416 赵寒旭 数字图像处理Hw2
## 文件结构
matlab_15331416_赵寒旭_hw2

* src: matlab源文件代码包

|项目文件|具体内容|
|---------|--------|
|average_filter.m|均值滤波器实例*|
|equalize.m |直方图均衡化实例*|
|equalize_hist.m|直方图均衡化函数|
|exercise.m|习题1.2测试*|
|filter2d.m|滤波器函数|
|highboost_filter.m|高提升滤波实例*|
|laplacian_filter.m|拉普拉斯滤波器实例*|




* report
----Report.pdf

* README.md

## 项目运行方式
标有*号的均为可直接运行的.m文件
